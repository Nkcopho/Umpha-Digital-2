<?php include './partials/layouts/layoutTop3.php' ?>

<header class="site-header aximo-header-section aximo-header3 bg-light3" id="sticky-menu">
    <div class="container">
        <nav class="navbar site-navbar">
            <!-- Brand Logo-->
            <div class="brand-logo">
                <a href="index.php">
                    <img src="assets/images/logo/logo-dark.svg" alt="" class="light-version-logo">
                </a>
            </div>
            <div class="menu-block-wrapper">
                <div class="menu-overlay"></div>
                <nav class="menu-block" id="append-menu-header">
                    <div class="mobile-menu-head">
                        <div class="go-back">
                            <i class="fa fa-angle-left"></i>
                        </div>
                        <div class="current-menu-title"></div>
                        <div class="mobile-menu-close">&times;</div>
                    </div>
                    <ul class="site-menu-main">
                        <li class="nav-item nav-item-has-children">
                            <a href="#" class="nav-link-item drop-trigger">Demo <i class="fas fa-angle-down"></i></a>
                            <ul class="sub-menu" id="submenu-1">
                                <li class="sub-menu--item">
                                    <a href="index.php">
                                        <span class="menu-item-text">Design Agency</span>
                                    </a>
                                </li>
                                <li class="sub-menu--item">
                                    <a href="index-02.php">
                                        <span class="menu-item-text">Startup Agency</span>
                                    </a>
                                </li>
                                <li class="sub-menu--item">
                                    <a href="index-03.php">
                                        <span class="menu-item-text">SEO Agency</span>
                                    </a>
                                </li>
                                <li class="sub-menu--item">
                                    <a href="index-04.php">
                                        <span class="menu-item-text">Business Consultation</span>
                                    </a>
                                </li>
                                <li class="sub-menu--item">
                                    <a href="index-05.php">
                                        <span class="menu-item-text">Digital Marketing</span>
                                    </a>
                                </li>
                                <li class="sub-menu--item">
                                    <a href="index-06.php">
                                        <span class="menu-item-text">Interior Design Agency</span>
                                    </a>
                                </li>
                                <li class="sub-menu--item">
                                    <a href="index-07.php">
                                        <span class="menu-item-text">Advertising agency</span>
                                    </a>
                                </li>
                            </ul>
                        </li>
                        <li class="nav-item">
                            <a href="about-us.php" class="nav-link-item">About Us</a>
                        </li>
                        <li class="nav-item nav-item-has-children">
                            <a href="#" class="nav-link-item drop-trigger">Pages <i class="fas fa-angle-down"></i></a>
                            <ul class="sub-menu" id="submenu-2">
                                <li class="sub-menu--item">
                                    <a href="about-us.php">
                                        <span class="menu-item-text">About Us</span>
                                    </a>
                                </li>
                                <li class="sub-menu--item">
                                    <a href="pricing.php">
                                        <span class="menu-item-text">Pricing</span>
                                    </a>
                                </li>
                                <li class="sub-menu--item nav-item-has-children">
                                    <a href="#" data-menu-get="h3" class="drop-trigger">blog <i class="fas fa-angle-down"></i></a>
                                    <ul class="sub-menu shape-none" id="submenu-3">
                                        <li class="sub-menu--item">
                                            <a href="blog.php">
                                                <span class="menu-item-text">Our Blog</span>
                                            </a>
                                        </li>
                                        <li class="sub-menu--item">
                                            <a href="blog-grid.php">
                                                <span class="menu-item-text">Blog grid</span>
                                            </a>
                                        </li>
                                        <li class="sub-menu--item">
                                            <a href="single-blog.php">
                                                <span class="menu-item-text">blog details</span>
                                            </a>
                                        </li>
                                    </ul>
                                </li>
                                <li class="sub-menu--item nav-item-has-children">
                                    <a href="#" data-menu-get="h3" class="drop-trigger">Service<i class="fas fa-angle-down"></i>
                                    </a>
                                    <ul class="sub-menu shape-none" id="submenu-4">
                                        <li class="sub-menu--item">
                                            <a href="service.php">
                                                <span class="menu-item-text">service</span>
                                            </a>
                                        </li>
                                        <li class="sub-menu--item">
                                            <a href="single-service.php">
                                                <span class="menu-item-text">service details</span>
                                            </a>
                                        </li>
                                    </ul>
                                </li>
                                <li class="sub-menu--item nav-item-has-children">
                                    <a href="#" data-menu-get="h3" class="drop-trigger">Team<i class="fas fa-angle-down"></i>
                                    </a>
                                    <ul class="sub-menu shape-none" id="submenu-5">
                                        <li class="sub-menu--item">
                                            <a href="team.php">
                                                <span class="menu-item-text">team</span>
                                            </a>
                                        </li>
                                        <li class="sub-menu--item">
                                            <a href="single-team.php">
                                                <span class="menu-item-text">team details</span>
                                            </a>
                                        </li>
                                    </ul>
                                </li>
                                <li class="sub-menu--item nav-item-has-children">
                                    <a href="#" data-menu-get="h3" class="drop-trigger">Portfolio<i class="fas fa-angle-down"></i>
                                    </a>
                                    <ul class="sub-menu shape-none" id="submenu-6">
                                        <li class="sub-menu--item">
                                            <a href="portfolio-02.php">
                                                <span class="menu-item-text">Portfolio One Column</span>
                                            </a>
                                        </li>
                                        <li class="sub-menu--item">
                                            <a href="portfolio-01.php">
                                                <span class="menu-item-text">Portfolio Two Column</span>
                                            </a>
                                        </li>
                                        <li class="sub-menu--item">
                                            <a href="single-portfolio.php">
                                                <span class="menu-item-text">Single Portfolio</span>
                                            </a>
                                        </li>
                                    </ul>
                                </li>
                                <li class="sub-menu--item nav-item-has-children">
                                    <a href="#" data-menu-get="h3" class="drop-trigger">Utility<i class="fas fa-angle-down"></i>
                                    </a>
                                    <ul class="sub-menu shape-none" id="submenu-7">
                                        <li class="sub-menu--item">
                                            <a href="faq.php">
                                                <span class="menu-item-text">faq</span>
                                            </a>
                                        </li>
                                        <li class="sub-menu--item">
                                            <a href="errors-404.php">
                                                <span class="menu-item-text">Error 404</span>
                                            </a>
                                        </li>
                                        <li class="sub-menu--item">
                                            <a href="testimonial.php">
                                                <span class="menu-item-text">testimonial</span>
                                            </a>
                                        </li>
                                        <li class="sub-menu--item">
                                            <a href="coming-soon.php">
                                                <span class="menu-item-text">Coming Soon</span>
                                            </a>
                                        </li>
                                    </ul>
                                </li>
                                <li class="sub-menu--item nav-item-has-children">
                                    <a href="#" data-menu-get="h3" class="drop-trigger">Account<i class="fas fa-angle-down"></i>
                                    </a>
                                    <ul class="sub-menu shape-none" id="submenu-8">
                                        <li class="sub-menu--item">
                                            <a href="sign-up.php">
                                                <span class="menu-item-text">sign up</span>
                                            </a>
                                        </li>
                                        <li class="sub-menu--item">
                                            <a href="sign-in.php">
                                                <span class="menu-item-text">sign in</span>
                                            </a>
                                        </li>
                                        <li class="sub-menu--item">
                                            <a href="reset-password.php">
                                                <span class="menu-item-text">reset password</span>
                                            </a>
                                        </li>
                                    </ul>
                                </li>
                            </ul>
                        </li>
                        <li class="nav-item nav-item-has-children">
                            <a href="#" class="nav-link-item drop-trigger">Blog <i class="fas fa-angle-down"></i></a>
                            <ul class="sub-menu" id="submenu-9">
                                <li class="sub-menu--item">
                                    <a href="blog.php">
                                        <span class="menu-item-text">blog</span>
                                    </a>
                                </li>
                                <li class="sub-menu--item">
                                    <a href="blog-grid.php">
                                        <span class="menu-item-text">Blog grid</span>
                                    </a>
                                </li>
                                <li class="sub-menu--item">
                                    <a href="single-blog.php">
                                        <span class="menu-item-text">blog Details</span>
                                    </a>
                                </li>
                            </ul>
                        </li>
                        <li class="nav-item">
                            <a href="contact-us.php" class="nav-link-item">Contact Us</a>
                        </li>
                    </ul>
                </nav>
            </div>

            <div class="header-btn header-btn-l1 ms-auto d-none d-xs-inline-flex">
                <div class="aximo-header-wrap">
                    <div class="aximo-social-icon header-social">
                        <ul>
                            <li>
                                <a href="https://twitter.com/" target="_blank">
                                    <i class="icon-twitter"></i>
                                </a>
                            </li>
                            <li>
                                <a href="https://facebook.com/" target="_blank">
                                    <i class="icon-facebook"></i>
                                </a>
                            </li>
                            <li>
                                <a href="https://www.instagram.com/" target="_blank">
                                    <i class="icon-instagram"></i>
                                </a>
                            </li>
                            <li>
                                <a href="https://www.linkedin.com/" target="_blank">
                                    <i class="icon-linkedin"></i>
                                </a>
                            </li>
                        </ul>
                    </div>
                    <a class="aximo-default-btn pill aximo-header-btn yellow-btn" href="contact-us.php">
                        <span class="aximo-label-up">Talk to an expert</span>
                        <span class="aximo-label-up">Talk to an expert</span>
                    </a>
                </div>
            </div>
            <!-- mobile menu trigger -->
            <div class="mobile-menu-trigger">
                <span></span>
            </div>
            <!--/.Mobile Menu Hamburger Ends-->
        </nav>
    </div>
</header>
<!--End landex-header-section -->

<div class="aximo-all-section bg-light3">

    <div class="aximo-hero-section3">
        <div class="container">
            <div class="row aximo_screenfix_right">
                <div class="col-lg-6 d-flex align-items-center">
                    <div class="aximo-hero-content3">
                        <p><span>#1 SEO agency for fast-growing companies</span></p>
                        <h1>
                            Provides the best ranking experience
                        </h1>
                        <p>We work to improve your business visibility within search engines, boost organic traffic to your website and rank for the most valuable keywords.</p>
                        <div class="aximo-hero-subscription">
                            <form action="#">
                                <input type="email" placeholder="Enter your email address">
                                <button id="aximo-hero-subscription-btn" type="submit">
                                    <span class="aximo-label-up">Get started</span>
                                    <span class="aximo-label-up">Get started</span>
                                </button>
                            </form>
                        </div>
                        <div class="aximo-hero-rating">
                            <ul>
                                <li><img src="assets/images/v3/star.svg" alt=""></li>
                                <li><img src="assets/images/v3/star.svg" alt=""></li>
                                <li><img src="assets/images/v3/star.svg" alt=""></li>
                                <li><img src="assets/images/v3/star.svg" alt=""></li>
                                <li><img src="assets/images/v3/star.svg" alt=""></li>
                                <li>4.8/5 stars based on 1K client reviews</li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="aximo-hero-thumb3-wrap">
                        <div class="aximo-hero-thumb3">
                            <img src="assets/images/v3/hero-thumb.png" alt="">
                            <div class="aximo-hero-thumb-shape2">
                                <img src="assets/images/v3/shape-monitor.png" alt="">
                            </div>
                            <div class="aximo-hero-thumb-shape3">
                                <img src="assets/images/v3/shape-ayna.png" alt="">
                            </div>
                        </div>
                        <div class="aximo-hero-thumb-shape1 wow wow fadeInRight" data-wow-delay="0s">
                            <img src="assets/images/v3/star-shape.png" alt="">
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
    <!-- End section -->

    <div class="aximo-counter-section dark-bg">
        <div id="aximo-counter"></div>
        <div class="container">
            <div class="aximo-counter-title">
                <p>Our results speak for our ability to succeed</p>
            </div>
            <div class="aximo-counter-wrap3">
                <div class="aximo-counter-data3 wow fadeInUpX" data-wow-delay="0.1s">
                    <h2><em>.</em><span data-percentage="13" class="aximo-counter"></span>+</h2>
                    <p>Years of experience</p>
                </div>
                <div class="aximo-counter-data3 wow fadeInUpX" data-wow-delay="0.2s">
                    <h2><em>.</em><span data-percentage="85" class="aximo-counter"></span>%</h2>
                    <p>Average Conversion Rate</p>
                </div>
                <div class="aximo-counter-data3 wow fadeInUpX" data-wow-delay="0.3s">
                    <h2><em>.</em><span data-percentage="60" class="aximo-counter"></span>m</h2>
                    <p>Traffic Generated</p>
                </div>
                <div class="aximo-counter-data3 wow fadeInUpX" data-wow-delay="0.4s">
                    <h2><em>.</em><span data-percentage="100" class="aximo-counter"></span>%</h2>
                    <p>Client satisfaction score</p>
                </div>
            </div>
        </div>

    </div>
    <!-- End section -->

    <div class="section aximo-section-padding2">
        <div class="container">
            <div class="row">
                <div class="col-lg-5">
                    <div class="aximo-content-thumb wow fadeInLeft" data-wow-delay="0.1s">
                        <img src="assets/images/v3/thumb1.png" alt="">
                        <div class="aximo-thumb-shape1">
                            <img src="assets/images/v3/shape2.png" alt="">
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 offset-lg-1">
                    <div class="aximo-default-content familjen-grotesk">
                        <h2>We strive for the best SEO quality</h2>
                        <p>We are a leading SEO company dedicated to helping brand grow their online presence & achieve higher search engine rankings and improve digital performance. </p>
                        <p>Whether you're a small local business or a global brand, we tailor our SEO services to meet your unique needs & goals.</p>
                    </div>
                    <div class="aximo-btn-wrap">
                        <a class="aximo-default-btn pill yellow-btn" href="contact-us.php">
                            <span class="aximo-label-up">Explore more</span>
                            <span class="aximo-label-up">Explore more</span>
                        </a>
                    </div>
                </div>
            </div>

        </div>
    </div>
    <!-- End section -->

    <div class="section aximo-section-padding6 overflow-hidden">
        <div class="container">
            <div class="row">
                <div class="col-lg-5 order-lg-1 offset-lg-1">
                    <div class="aximo-content-thumb wow fadeInRight" data-wow-delay="0.2s">
                        <img src="assets/images/v3/thumb2.png" alt="">
                        <div class="aximo-thumb-shape2">
                            <img src="assets/images/v3/shape1.png" alt="">
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="aximo-default-content familjen-grotesk">
                        <h2>Increase revenue with custom SEO</h2>
                        <p>Our SEO agency will help you reach new audiences, increase your website performance, and accelerate your reputation.</p>
                        <div class="aximo-list-icon">
                            <ul>
                                <li><img src="assets/images/v3/check.svg" alt=""> On-page optimizing your web pages to improve rankings</li>
                                <li><img src="assets/images/v3/check.svg" alt=""> Keyword research to identify relevant search and phrases</li>
                                <li><img src="assets/images/v3/check.svg" alt=""> Continuously monitor search engine algorithm changes</li>
                            </ul>
                        </div>

                    </div>
                </div>
            </div>

        </div>
    </div>
    <!-- End section -->

    <div class="section aximo-section-padding dark-bg overflow-hidden position-relative">
        <div class="container">
            <div class="aximo-section-title center familjen-grotesk light">
                <h2>
                    Our professional SEO services for you
                </h2>
            </div>
            <div class="aximo-iconbox-column">
                <div class="aximo-iconbox-wrap3 wow fadeInUpX" data-wow-delay="0.1s">
                    <div class="aximo-iconbox-icon3">
                        <img src="assets/images/v3/icon1.svg" alt="">
                    </div>
                    <div class="aximo-iconbox-data3">
                        <h3>On-Page SEO</h3>
                        <p>On-page SEO aims to improve users website content and structure to improve its ranking on search engine results pages.</p>
                        <a class="aximo-service-icon" href="single-service.php"><img src="assets/images/icon/arrow-right4.svg" alt=""></a>
                    </div>
                </div>
                <div class="aximo-iconbox-wrap3 wow fadeInUpX" data-wow-delay="0.2s">
                    <div class="aximo-iconbox-icon3">
                        <img src="assets/images/v3/icon2.svg" alt="">
                    </div>
                    <div class="aximo-iconbox-data3">
                        <h3>Technical SEO</h3>
                        <p>Technical SEO helps search engines crawl & index a site more effectively. Its performance and accessibility to search engines. </p>
                        <a class="aximo-service-icon" href="single-service.php"><img src="assets/images/icon/arrow-right4.svg" alt=""></a>
                    </div>
                </div>
                <div class="aximo-iconbox-wrap3 wow fadeInUpX" data-wow-delay="0.3s">
                    <div class="aximo-iconbox-icon3">
                        <img src="assets/images/v3/icon3.svg" alt="">
                    </div>
                    <div class="aximo-iconbox-data3">
                        <h3>Keyword Research</h3>
                        <p>We perform keyword research to identify the most relevant and high-traffic keywords and phrases for a client's industry.</p>
                        <a class="aximo-service-icon" href="single-service.php"><img src="assets/images/icon/arrow-right4.svg" alt=""></a>
                    </div>
                </div>
                <div class="aximo-iconbox-wrap3 wow fadeInUpX" data-wow-delay="0.4s">
                    <div class="aximo-iconbox-icon3">
                        <img src="assets/images/v3/icon4.svg" alt="">
                    </div>
                    <div class="aximo-iconbox-data3">
                        <h3>Content Creation</h3>
                        <p>Content can take many forms, including blog posts, articles, videos, infographics & high-quality and informative content.</p>
                        <a class="aximo-service-icon" href="single-service.php"><img src="assets/images/icon/arrow-right4.svg" alt=""></a>
                    </div>
                </div>
            </div>
        </div>

        <div class="aximo-iconbox-shape wow fadeInDown" data-wow-delay="0.2s">
            <img src="assets/images/v3/star-shape-half.png" alt="">
        </div>

    </div>
    <!-- End section -->

    <div class="section aximo-section-padding2">
        <div class="container">
            <div class="row">
                <div class="col-lg-5">
                    <div class="aximo-content-thumb-wrap">
                        <div class="aximo-content-thumb2 wow fadeInUpX" data-wow-delay="0.1s">
                            <img src="assets/images/v3/thumb3.png" alt="">
                        </div>
                        <div class="aximo-thumb-shape1">
                            <img src="assets/images/v3/shape3.png" alt="">
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 offset-lg-1">
                    <div class="aximo-default-content familjen-grotesk">
                        <h2>Our simplified & impactful steps</h2>
                        <p>We will work to understand more about user's business and goals & create a simple step-by-step SEO plan to help them.</p>
                        <div class="aximo-accordion-wrap aximo-accordion-wrap3">
                            <div class="aximo-accordion-item open">
                                <div class="aximo-accordion-header">
                                    <p>Keyword Research and On-Page Optimization</p>
                                </div>
                                <div class="aximo-accordion-body">
                                    <p>Start by researching and selecting relevant keywords and phrases that your target audience is likely to use.</p>
                                </div>
                            </div>
                            <div class="aximo-accordion-item">
                                <div class="aximo-accordion-header">
                                    <p>Off-Page SEO and Link Building</p>
                                </div>
                                <div class="aximo-accordion-body">
                                    <p>If your business has a physical presence, optimize your website for local search by claiming.</p>
                                </div>
                            </div>
                            <div class="aximo-accordion-item">
                                <div class="aximo-accordion-header">
                                    <p>Regular Monitoring and Content Creation</p>
                                </div>
                                <div class="aximo-accordion-body">
                                    <p>Regularly monitor your website's performance using tools like Google Analytics & Google Search Console.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End section -->

    <div class="aximo-auto-text-slider-section">
        <div class="swiper aximo-auto-slider">
            <div class="swiper-wrapper">
                <div class="swiper-slide">
                    <div class="aximo-auto-slider-item">
                        <h3># Online Marketing</h3>
                    </div>
                </div>
                <div class="swiper-slide">
                    <div class="aximo-auto-slider-item">
                        <h3># SEO Expert</h3>
                    </div>
                </div>
                <div class="swiper-slide">
                    <div class="aximo-auto-slider-item">
                        <h3># Content Marketing</h3>
                    </div>
                </div>
                <div class="swiper-slide">
                    <div class="aximo-auto-slider-item">
                        <h3># Link Building</h3>
                    </div>
                </div>
                <div class="swiper-slide">
                    <div class="aximo-auto-slider-item">
                        <h3># Digital Strategy</h3>
                    </div>
                </div>
                <div class="swiper-slide">
                    <div class="aximo-auto-slider-item">
                        <h3># Google Rankings</h3>
                    </div>
                </div>
                <div class="swiper-slide">
                    <div class="aximo-auto-slider-item">
                        <h3># Online Marketing</h3>
                    </div>
                </div>
                <div class="swiper-slide">
                    <div class="aximo-auto-slider-item">
                        <h3># SEO Expert</h3>
                    </div>
                </div>
                <div class="swiper-slide">
                    <div class="aximo-auto-slider-item">
                        <h3># Content Marketing</h3>
                    </div>
                </div>
                <div class="swiper-slide">
                    <div class="aximo-auto-slider-item">
                        <h3># Link Building</h3>
                    </div>
                </div>
                <div class="swiper-slide">
                    <div class="aximo-auto-slider-item">
                        <h3># Digital Strategy</h3>
                    </div>
                </div>
                <div class="swiper-slide">
                    <div class="aximo-auto-slider-item">
                        <h3># Google Rankings</h3>
                    </div>
                </div>
                <div class="swiper-slide">
                    <div class="aximo-auto-slider-item">
                        <h3># Online Marketing</h3>
                    </div>
                </div>
                <div class="swiper-slide">
                    <div class="aximo-auto-slider-item">
                        <h3># SEO Expert</h3>
                    </div>
                </div>
                <div class="swiper-slide">
                    <div class="aximo-auto-slider-item">
                        <h3># Content Marketing</h3>
                    </div>
                </div>
                <div class="swiper-slide">
                    <div class="aximo-auto-slider-item">
                        <h3># Link Building</h3>
                    </div>
                </div>
                <div class="swiper-slide">
                    <div class="aximo-auto-slider-item">
                        <h3># Digital Strategy</h3>
                    </div>
                </div>
                <div class="swiper-slide">
                    <div class="aximo-auto-slider-item">
                        <h3># Google Rankings</h3>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End section -->

    <div class="section aximo-section-padding3 position-relative">
        <div class="container">
            <div class="aximo-section-title familjen-grotesk">
                <div class="row">
                    <div class="col-lg-6">
                        <h2>Increase revenue with custom SEO</h2>
                    </div>
                    <div class="col-lg-6 d-flex align-items-center justify-content-end">
                        <div class="aximo-title-btn">
                            <a class="aximo-default-btn pill yellow-btn" href="team.php">
                                <span class="aximo-label-up">Meet our team</span>
                                <span class="aximo-label-up">Meet our team</span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-xl-4 col-md-6">
                    <div class="aximo-team-wrap2 wow fadeInUpX" data-wow-delay="0.1s">
                        <div class="aximo-team-thumb2">
                            <img src="assets/images/team/team5.png" alt="">
                        </div>
                        <div class="aximo-team-data2">
                            <a href="single-team.php">
                                <h4>Adrew Smith</h4>
                            </a>
                            <p>Senior SEO Manager</p>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-md-6">
                    <div class="aximo-team-wrap2 wow fadeInUpX" data-wow-delay="0.2s">
                        <div class="aximo-team-thumb2">
                            <img src="assets/images/team/team6.png" alt="">
                        </div>
                        <div class="aximo-team-data2">
                            <a href="single-team.php">
                                <h4>Jones Jack</h4>
                            </a>
                            <p>Strategy Director</p>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-md-6">
                    <div class="aximo-team-wrap2 wow fadeInUpX" data-wow-delay="0.3s">
                        <div class="aximo-team-thumb2">
                            <img src="assets/images/team/team7.png" alt="">
                        </div>
                        <div class="aximo-team-data2">
                            <a href="single-team.php">
                                <h4>Marsal Straw</h4>
                            </a>
                            <p>SEO Content Writer</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="aximo-star-shape-half wow fadeInLeft" data-wow-delay="0.2s">
            <img src="assets/images/v3/star-shape-half2.png" alt="">
        </div>
    </div>
    <!-- End section -->

    <div class="section aximo-section-padding6">
        <div class="container">
            <div class="aximo-section-title center familjen-grotesk">
                <h2>
                    Increase revenue with custom SEO
                </h2>
            </div>
            <div class="aximo-accordion-wrap aximo-accordion-wrap4">
                <div class="aximo-accordion-item open">
                    <div class="aximo-accordion-header">
                        <h3>What is SEO?</h3>
                    </div>
                    <div class="aximo-accordion-body">
                        <p>SEO, or Search Engine Optimization, is a set of strategies and techniques aimed at improving a website's visibility in search engine results pages (SERPs) to increase organic (non-paid) traffic.</p>
                    </div>
                </div>
                <div class="aximo-accordion-item">
                    <div class="aximo-accordion-header">
                        <h3>Why is SEO important for my website?</h3>
                    </div>
                    <div class="aximo-accordion-body">
                        <p>SEO is essential because it helps your website rank higher in search results, making it more visible to potential visitors. This can lead to increased organic traffic, better brand exposure, and potential business growth.</p>
                    </div>
                </div>
                <div class="aximo-accordion-item">
                    <div class="aximo-accordion-header">
                        <h3>How long does it take to see results from SEO?</h3>
                    </div>
                    <div class="aximo-accordion-body">
                        <p>SEO is an ongoing process, and the time it takes to see results can vary based on factors like the competitiveness of your industry and the specific strategies you use. Generally, it can take several months to see significant improvements.</p>
                    </div>
                </div>
                <div class="aximo-accordion-item">
                    <div class="aximo-accordion-header">
                        <h3>How can I improve my website's load speed for SEO?</h3>
                    </div>
                    <div class="aximo-accordion-body">
                        <p>You can enhance website speed by optimizing images, using content delivery networks (CDNs), reducing unnecessary plugins, and enabling browser caching, among other techniques.</p>
                    </div>
                </div>
                <div class="aximo-accordion-item">
                    <div class="aximo-accordion-header">
                        <h3>How can I track the success of my SEO efforts?</h3>
                    </div>
                    <div class="aximo-accordion-body">
                        <p>You can track SEO success by using tools like Google Analytics and Google Search Console. Monitor key metrics, such as organic traffic, keyword rankings, click-through rates, and conversion rates.</p>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <!-- End section -->

    <div class="section dark-bg aximo-section-padding2 position-relative overflow-hidden">
        <div class="container">
            <div class="row">
                <div class="col-lg-7">
                    <div class="aximo-default-content familjen-grotesk light m-right-gap">
                        <h2>Want to boost your business with our SEO expertise?</h2>
                        <p>Experienced SEO experts proven strategies & innovative techniques to increase your website's visibility, drive organic traffic, and improve your digital performance and grow your online reach.</p>
                        <div class="aximo-contact-info">
                            <h3>Contact us directly:</h3>
                            <ul>
                                <li>
                                    <a href="">
                                        <i class="icon-phone"></i>
                                        +088-234-6849
                                    </a>

                                </li>
                                <li>
                                    <a href="">
                                        <i class="icon-message"></i>
                                        pixcelsthemes@gmail.com
                                    </a>
                                </li>
                                <li>
                                    <a href="">
                                        <i class="icon-map"></i>
                                        Haward Street,10203 USA
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-5">
                    <div class="aximo-form-wrap2">
                        <h3>Send us a message</h3>
                        <p>Fill out the form and our expert will get back to you with a free analysis and proposal</p>
                        <form action="#">
                            <div class="aximo-form-field2">
                                <input type="text" placeholder="Enter full name">
                            </div>
                            <div class="aximo-form-field2">
                                <input type="email" placeholder="Enter email address">
                            </div>
                            <div class="aximo-form-field2">
                                <textarea name="textarea" placeholder="Write us your questions"></textarea>
                            </div>
                            <button id="aximo-submit-btn2" type="submit">
                                <span class="aximo-label-up">Submit now</span>
                                <span class="aximo-label-up">Submit now</span>
                            </button>
                        </form>
                    </div>
                </div>
            </div>

        </div>
        <div class="aximo-star-shape-half2 wow fadeInUp" data-wow-delay="0.2s">
            <img src="assets/images/v3/star-shape-half3.png" alt="">
        </div>
    </div>
    <!-- End section -->
</div>

<footer class="aximo-footer-section">
    <div class="container">
        <div class="aximo-footer-top2">
            <a href=""><img src="assets/images/v3/logo-large.svg" alt=""></a>
        </div>
        <div class="aximo-footer-bottom three">
            <div class="row">
                <div class="col-xl-6">
                    <div class="aximo-copywright three">
                        <p>&copy;Copyright 2024, All Rights Reserved by Pixcels Themes</p>
                    </div>
                </div>
                <div class="col-xl-6">
                    <div class="aximo-footer-menu2">
                        <ul>
                            <li><a href="">Home</a></li>
                            <li><a href="">About Us</a></li>
                            <li><a href="">Services</a></li>
                            <li><a href="">Projects</a></li>
                            <li><a href="">Pages</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>

<?php include './partials/layouts/layoutBottom2.php' ?>