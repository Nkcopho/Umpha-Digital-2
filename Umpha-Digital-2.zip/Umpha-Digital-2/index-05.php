<?php include './partials/layouts/layoutTop3.php' ?>

<header class="site-header site-header--menu-center aximo-header-section aximo-header5 green-bg" id="sticky-menu">
    <div class="container">
        <nav class="navbar site-navbar">
            <!-- Brand Logo-->
            <div class="brand-logo">
                <a href="index.php">
                    <img src="assets/images/logo/logo-white.svg" alt="" class="light-version-logo">
                </a>
            </div>
            <div class="menu-block-wrapper">
                <div class="menu-overlay"></div>
                <nav class="menu-block" id="append-menu-header">
                    <div class="mobile-menu-head">
                        <div class="go-back">
                            <i class="fa fa-angle-left"></i>
                        </div>
                        <div class="current-menu-title"></div>
                        <div class="mobile-menu-close">&times;</div>
                    </div>
                    <ul class="site-menu-main">
                        <li class="nav-item nav-item-has-children">
                            <a href="#" class="nav-link-item drop-trigger">Demo <i class="fas fa-angle-down"></i></a>
                            <ul class="sub-menu" id="submenu-1">
                                <li class="sub-menu--item">
                                    <a href="index.php">
                                        <span class="menu-item-text">Design Agency</span>
                                    </a>
                                </li>
                                <li class="sub-menu--item">
                                    <a href="index-02.php">
                                        <span class="menu-item-text">Startup Agency</span>
                                    </a>
                                </li>
                                <li class="sub-menu--item">
                                    <a href="index-03.php">
                                        <span class="menu-item-text">SEO Agency</span>
                                    </a>
                                </li>
                                <li class="sub-menu--item">
                                    <a href="index-04.php">
                                        <span class="menu-item-text">Business Consultation</span>
                                    </a>
                                </li>
                                <li class="sub-menu--item">
                                    <a href="index-05.php">
                                        <span class="menu-item-text">Digital Marketing</span>
                                    </a>
                                </li>
                                <li class="sub-menu--item">
                                    <a href="index-06.php">
                                        <span class="menu-item-text">Interior Design Agency</span>
                                    </a>
                                </li>
                                <li class="sub-menu--item">
                                    <a href="index-07.php">
                                        <span class="menu-item-text">Advertising agency</span>
                                    </a>
                                </li>
                            </ul>
                        </li>
                        <li class="nav-item">
                            <a href="about-us.php" class="nav-link-item">About Us</a>
                        </li>
                        <li class="nav-item nav-item-has-children">
                            <a href="#" class="nav-link-item drop-trigger">Pages <i class="fas fa-angle-down"></i></a>
                            <ul class="sub-menu" id="submenu-2">
                                <li class="sub-menu--item">
                                    <a href="about-us.php">
                                        <span class="menu-item-text">About Us</span>
                                    </a>
                                </li>
                                <li class="sub-menu--item">
                                    <a href="pricing.php">
                                        <span class="menu-item-text">Pricing</span>
                                    </a>
                                </li>
                                <li class="sub-menu--item nav-item-has-children">
                                    <a href="#" data-menu-get="h3" class="drop-trigger">blog <i class="fas fa-angle-down"></i></a>
                                    <ul class="sub-menu shape-none" id="submenu-3">
                                        <li class="sub-menu--item">
                                            <a href="blog.php">
                                                <span class="menu-item-text">Our Blog</span>
                                            </a>
                                        </li>
                                        <li class="sub-menu--item">
                                            <a href="blog-grid.php">
                                                <span class="menu-item-text">Blog grid</span>
                                            </a>
                                        </li>
                                        <li class="sub-menu--item">
                                            <a href="single-blog.php">
                                                <span class="menu-item-text">blog details</span>
                                            </a>
                                        </li>
                                    </ul>
                                </li>
                                <li class="sub-menu--item nav-item-has-children">
                                    <a href="#" data-menu-get="h3" class="drop-trigger">Service<i class="fas fa-angle-down"></i>
                                    </a>
                                    <ul class="sub-menu shape-none" id="submenu-4">
                                        <li class="sub-menu--item">
                                            <a href="service.php">
                                                <span class="menu-item-text">service</span>
                                            </a>
                                        </li>
                                        <li class="sub-menu--item">
                                            <a href="single-service.php">
                                                <span class="menu-item-text">service details</span>
                                            </a>
                                        </li>
                                    </ul>
                                </li>
                                <li class="sub-menu--item nav-item-has-children">
                                    <a href="#" data-menu-get="h3" class="drop-trigger">Team<i class="fas fa-angle-down"></i>
                                    </a>
                                    <ul class="sub-menu shape-none" id="submenu-5">
                                        <li class="sub-menu--item">
                                            <a href="team.php">
                                                <span class="menu-item-text">team</span>
                                            </a>
                                        </li>
                                        <li class="sub-menu--item">
                                            <a href="single-team.php">
                                                <span class="menu-item-text">team details</span>
                                            </a>
                                        </li>
                                    </ul>
                                </li>
                                <li class="sub-menu--item nav-item-has-children">
                                    <a href="#" data-menu-get="h3" class="drop-trigger">Portfolio<i class="fas fa-angle-down"></i>
                                    </a>
                                    <ul class="sub-menu shape-none" id="submenu-6">
                                        <li class="sub-menu--item">
                                            <a href="portfolio-02.php">
                                                <span class="menu-item-text">Portfolio One Column</span>
                                            </a>
                                        </li>
                                        <li class="sub-menu--item">
                                            <a href="portfolio-01.php">
                                                <span class="menu-item-text">Portfolio Two Column</span>
                                            </a>
                                        </li>
                                        <li class="sub-menu--item">
                                            <a href="single-portfolio.php">
                                                <span class="menu-item-text">Single Portfolio</span>
                                            </a>
                                        </li>
                                    </ul>
                                </li>
                                <li class="sub-menu--item nav-item-has-children">
                                    <a href="#" data-menu-get="h3" class="drop-trigger">Utility<i class="fas fa-angle-down"></i>
                                    </a>
                                    <ul class="sub-menu shape-none" id="submenu-7">
                                        <li class="sub-menu--item">
                                            <a href="faq.php">
                                                <span class="menu-item-text">faq</span>
                                            </a>
                                        </li>
                                        <li class="sub-menu--item">
                                            <a href="errors-404.php">
                                                <span class="menu-item-text">Error 404</span>
                                            </a>
                                        </li>
                                        <li class="sub-menu--item">
                                            <a href="testimonial.php">
                                                <span class="menu-item-text">testimonial</span>
                                            </a>
                                        </li>
                                        <li class="sub-menu--item">
                                            <a href="coming-soon.php">
                                                <span class="menu-item-text">Coming Soon</span>
                                            </a>
                                        </li>
                                    </ul>
                                </li>
                                <li class="sub-menu--item nav-item-has-children">
                                    <a href="#" data-menu-get="h3" class="drop-trigger">Account<i class="fas fa-angle-down"></i>
                                    </a>
                                    <ul class="sub-menu shape-none" id="submenu-8">
                                        <li class="sub-menu--item">
                                            <a href="sign-up.php">
                                                <span class="menu-item-text">sign up</span>
                                            </a>
                                        </li>
                                        <li class="sub-menu--item">
                                            <a href="sign-in.php">
                                                <span class="menu-item-text">sign in</span>
                                            </a>
                                        </li>
                                        <li class="sub-menu--item">
                                            <a href="reset-password.php">
                                                <span class="menu-item-text">reset password</span>
                                            </a>
                                        </li>
                                    </ul>
                                </li>
                            </ul>
                        </li>
                        <li class="nav-item nav-item-has-children">
                            <a href="#" class="nav-link-item drop-trigger">Blog <i class="fas fa-angle-down"></i></a>
                            <ul class="sub-menu" id="submenu-9">
                                <li class="sub-menu--item">
                                    <a href="blog.php">
                                        <span class="menu-item-text">blog</span>
                                    </a>
                                </li>
                                <li class="sub-menu--item">
                                    <a href="blog-grid.php">
                                        <span class="menu-item-text">Blog grid</span>
                                    </a>
                                </li>
                                <li class="sub-menu--item">
                                    <a href="single-blog.php">
                                        <span class="menu-item-text">blog Details</span>
                                    </a>
                                </li>
                            </ul>
                        </li>
                        <li class="nav-item">
                            <a href="contact-us.php" class="nav-link-item">Contact Us</a>
                        </li>
                    </ul>
                </nav>
            </div>
            <div class="header-btn header-btn-l1 ms-auto d-none d-xs-inline-flex">
                <a class="aximo-default-btn aximo-header-btn pill corn-btn" href="">
                    <span class="aximo-label-up">Contact Us</span>
                    <span class="aximo-label-up">Contact Us</span>
                </a>
            </div>
            <!-- mobile menu trigger -->
            <div class="mobile-menu-trigger light">
                <span></span>
            </div>
            <!--/.Mobile Menu Hamburger Ends-->
        </nav>
    </div>
</header>
<!--End landex-header-section -->

<div class="aximo-all-section bg-light6">

    <div class="aximo-hero-section5 green-bg">
        <div class="container">
            <div class="aximo-hero-content5">
                <h1>
                    Increase your brand awareness
                    <span class="aximo-hero-shape-title">
                        digitally
                        <img class="aximo-hero-wave-shape" src="assets/images/v5/shape1.png" alt="">
                    </span>
                </h1>
                <p>As a digital marketing agency, we specialize in providing a range of online marketing and advertising-related services. We help businesses and individuals promote your product, service, or brand through various digital channels.</p>
                <div class="aximo-hero-btn-wrap center">
                    <a class="aximo-default-btn pill corn-btn wow fadeInUpX" data-wow-delay="0.1s" href="contact-us.php">
                        <span class="aximo-label-up">Let's Talk</span>
                        <span class="aximo-label-up">Let's Talk</span>
                    </a>
                    <a class="aximo-default-btn aximo-default-btn-outline pill outline-white wow fadeInUpX" data-wow-delay="0.2s" href="single-service.php">
                        <span class="aximo-label-up">Explore Our Services</span>
                        <span class="aximo-label-up">Explore Our Services</span>
                    </a>
                </div>
            </div>
        </div>
    </div>
    <!-- End sction -->

    <div class="aximo-video-section2 extra-side-margin wow fadeInUpX" data-wow-delay="0s">
        <img src="assets/images/v5/video-bg.png" alt="">
        <a class="aximo-video-popup play-btn-size video-init" href="https://www.youtube.com/watch?v=7e90gBu4pas">
            <img src="assets/images/v5/play-btn.png" alt="">
            <div class="waves wave-1"></div>
            <div class="waves wave-2"></div>
            <div class="waves wave-3"></div>
        </a>
        <div class="aximo-video-shape">
            <img src="assets/images/v5/shape2.png" alt="">
        </div>
    </div>
    <!-- End section -->

    <div class="section aximo-section-padding3">
        <div class="container">
            <div class="aximo-section-title libre-font">
                <div class="row">
                    <div class="col-lg-7">
                        <h2>Our key feature for productivity gains</h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-xl-4 col-lg-6">
                    <div class="aximo-iconbox-wrap6 wow fadeInUpX" data-wow-delay="0s">
                        <div class="aximo-iconbox-icon6">
                            <img src="assets/images/v5/icon1.svg" alt="">
                        </div>
                        <div class="aximo-iconbox-data6">
                            <h3>Responsive Results</h3>
                            <p>We help businesses & individuals promote their products, services or brands through various digital channels and platforms.</p>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-6">
                    <div class="aximo-iconbox-wrap6 wow fadeInUpX" data-wow-delay="0.1s">
                        <div class="aximo-iconbox-icon6">
                            <img src="assets/images/v5/icon2.svg" alt="">
                        </div>
                        <div class="aximo-iconbox-data6">
                            <h3>Data-Driven Approach</h3>
                            <p>Effective digital marketing relies heavily on data and analytics. We often have a strong emphasis on collecting and analyzing data.</p>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-6">
                    <div class="aximo-iconbox-wrap6 wow fadeInUpX" data-wow-delay="0.2s">
                        <div class="aximo-iconbox-icon6">
                            <img src="assets/images/v5/icon3.svg" alt="">
                        </div>
                        <div class="aximo-iconbox-data6">
                            <h3>Customized Strategies</h3>
                            <p>We maximize the client's online presence and achieve their specific objectives. Customization is the key to effective and impactful.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End section -->

    <div class="aximo-wave-shape extra-side-margin">
        <img src="assets/images/v5/shape3.png" alt="">
    </div>
    <!-- End shape -->

    <div class="section aximo-section-padding4">
        <div class="container">
            <div class="row">
                <div class="col-lg-5">
                    <div class="aximo-content-thumb3 wow fadeInLeft" data-wow-delay="0.1s">
                        <img src="assets/images/v5/thumb1.png" alt="">
                    </div>
                </div>
                <div class="col-lg-7 d-flex align-items-center">
                    <div class="aximo-default-content libre-font m-left-gap-small">
                        <h2>Making your brand bigger than ever</h2>
                        <p>We help businesses & organizations promote their products, services or brands in the online world with 12 years of experience. We have become a leader in digital experiences, web design, and branding. </p>
                        <p>We love what we do with our clients to ensure their positioning and digital transformation ensure the business meets every standard.</p>
                        <div class="aximo-btn-wrap">
                            <a class="aximo-default-btn pill corn-btn" href="contact-us.php">
                                <span class="aximo-label-up">Explore more</span>
                                <span class="aximo-label-up">Explore more</span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End section -->

    <div class="aximo-counter-section2">
        <div id="aximo-counter"></div>
        <div class="container">
            <div class="aximo-counter-wrap5">
                <div class="aximo-counter-data5 wow fadeInUpX" data-wow-delay="0.1s">
                    <h2><span data-percentage="12" class="aximo-counter"></span>+</h2>
                    <p>Years of experience</p>
                </div>
                <div class="aximo-counter-data5 wow fadeInUpX" data-wow-delay="0.2s">
                    <h2><span data-percentage="85" class="aximo-counter"></span>k</h2>
                    <p>Active monthly users</p>
                </div>
                <div class="aximo-counter-data5 wow fadeInUpX" data-wow-delay="0.3s">
                    <h2><span data-percentage="60" class="aximo-counter"></span>k+</h2>
                    <p>Project completed</p>
                </div>
                <div class="aximo-counter-data5 wow fadeInUpX" data-wow-delay="0.4s">
                    <h2><span data-percentage="4.8" class="aximo-counter"></span>/5</h2>
                    <p>Total success rate</p>
                </div>
            </div>
        </div>
    </div>
    <!-- End section -->

    <div class="aximo-marketing-services-section extra-side-margin green-bg aximo-section-padding2">
        <div class="container">
            <div class="aximo-section-title center light libre-font">
                <h2>Exceptional digital marketing services</h2>
            </div>
            <div class="aximo-marketing-services-item">
                <div class="aximo-marketing-services-icon">
                    <img src="assets/images/v5/t_icon1.svg" alt="">
                    <h3>Online Advertising:</h3>
                </div>
                <div class="aximo-marketing-services-data">
                    <p>This includes pay-per-click (PPC) advertising on platforms like Google Ads and social media.</p>
                </div>
                <div class="aximo-marketing-services-btn">
                    <a class="aximo-default-btn aximo-default-btn-outline pill outline-white marketing-services-btn" href="single-service.php">
                        Choose Service
                    </a>
                </div>
            </div>
            <div class="aximo-marketing-services-item">
                <div class="aximo-marketing-services-icon">
                    <img src="assets/images/v5/t_icon2.svg" alt="">
                    <h3>SEO Services:</h3>
                </div>
                <div class="aximo-marketing-services-data">
                    <p>Driving organic (non-paid) traffic. This involves on-page and off-page SEO techniques.</p>
                </div>
                <div class="aximo-marketing-services-btn">
                    <a class="aximo-default-btn aximo-default-btn-outline pill outline-white marketing-services-btn" href="single-service.php">
                        Choose Service
                    </a>
                </div>
            </div>
            <div class="aximo-marketing-services-item">
                <div class="aximo-marketing-services-icon">
                    <img src="assets/images/v5/t_icon3.svg" alt="">
                    <h3>Content Marketing:</h3>
                </div>
                <div class="aximo-marketing-services-data">
                    <p>Blog posts, articles, videos, and infographics, to engage and educate all target audiences.</p>
                </div>
                <div class="aximo-marketing-services-btn">
                    <a class="aximo-default-btn aximo-default-btn-outline pill outline-white marketing-services-btn" href="single-service.php">
                        Choose Service
                    </a>
                </div>
            </div>
            <div class="aximo-marketing-services-item">
                <div class="aximo-marketing-services-icon">
                    <img src="assets/images/v5/t_icon4.svg" alt="">
                    <h3>Email Marketing:</h3>
                </div>
                <div class="aximo-marketing-services-data">
                    <p>Crafting & executing email campaigns to nurture leads, retain customers, and promote.</p>
                </div>
                <div class="aximo-marketing-services-btn">
                    <a class="aximo-default-btn aximo-default-btn-outline pill outline-white marketing-services-btn" href="single-service.php">
                        Choose Service
                    </a>
                </div>
            </div>
            <div class="aximo-marketing-services-item">
                <div class="aximo-marketing-services-icon">
                    <img src="assets/images/v5/t_icon5.svg" alt="">
                    <h3>Data Analysis:</h3>
                </div>
                <div class="aximo-marketing-services-data">
                    <p>Performance to make data-driven decisions and refine strategies for better results.</p>
                </div>
                <div class="aximo-marketing-services-btn">
                    <a class="aximo-default-btn aximo-default-btn-outline pill outline-white marketing-services-btn" href="single-service.php">
                        Choose Service
                    </a>
                </div>
            </div>
        </div>
    </div>
    <!-- End section -->

    <div class="aximo-project-section2">
        <div class="container">
            <div class="aximo-section-title libre-font">
                <div class="row">
                    <div class="col-lg-7">
                        <h2>Successful projects that represent us</h2>
                    </div>
                    <div class="col-lg-5 d-flex align-items-end justify-content-end">
                        <div class="aximo-title-btn">
                            <a class="aximo-default-btn pill corn-btn" href="portfolio-01.php">
                                <span class="aximo-label-up">View All Works</span>
                                <span class="aximo-label-up">View All Works</span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-5">
                    <div class="aximo-project-wrap4 wow fadeInUpX" data-wow-delay="0.1s">
                        <div class="aximo-project-thumb4">
                            <img src="assets/images/portfolio/p_12.png" alt="">
                            <a class="aximo-project-view" href="single-portfolio.php">
                                View
                            </a>
                        </div>
                        <div class="aximo-project-data4">
                            <a href="single-portfolio.php">
                                <h3>Website Development</h3>
                            </a>
                            <div class="aximo-project-meta">
                                <ul>
                                    <li><a href="">XYZ Company</a></li>
                                    <li><a href="">Web Design</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-7">
                    <div class="aximo-project-wrap4 wow fadeInUpX" data-wow-delay="0.2s">
                        <div class="aximo-project-thumb4">
                            <img src="assets/images/portfolio/p_13.png" alt="">
                            <a class="aximo-project-view" href="single-portfolio.php">
                                View
                            </a>
                        </div>
                        <div class="aximo-project-data4">
                            <a href="single-portfolio.php">
                                <h3>Online Advertising Campaigns</h3>
                            </a>
                            <div class="aximo-project-meta">
                                <ul>
                                    <li><a href="">J&J Group</a></li>
                                    <li><a href="">Marketing</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-7">
                    <div class="aximo-project-wrap4 wow fadeInUpX" data-wow-delay="0.3s">
                        <div class="aximo-project-thumb4">
                            <img src="assets/images/portfolio/p_14.png" alt="">
                            <a class="aximo-project-view" href="single-portfolio.php">
                                View
                            </a>
                        </div>
                        <div class="aximo-project-data4">
                            <a href="single-portfolio.php">
                                <h3>Online Reputation Management</h3>
                            </a>
                            <div class="aximo-project-meta">
                                <ul>
                                    <li><a href="">McCompany</a></li>
                                    <li><a href="">Branding</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-5">
                    <div class="aximo-project-wrap4 wow fadeInUpX" data-wow-delay="0.4s">
                        <div class="aximo-project-thumb4">
                            <img src="assets/images/portfolio/p_15.png" alt="">
                            <a class="aximo-project-view" href="single-portfolio.php">
                                View
                            </a>
                        </div>
                        <div class="aximo-project-data4">
                            <a href="single-portfolio.php">
                                <h3>Affiliate Marketing</h3>
                            </a>
                            <div class="aximo-project-meta">
                                <ul>
                                    <li><a href="">Walmart</a></li>
                                    <li><a href="">Sale Marketing</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End section -->

    <div class="aximo-wave-shape extra-side-margin">
        <img src="assets/images/v5/shape3.png" alt="">
    </div>
    <!-- End shape-->

    <div class="section aximo-section-padding3">
        <div class="container">
            <div class="aximo-section-title center libre-font">
                <h2>
                    Get answers to all your questions
                </h2>
            </div>
            <div class="aximo-accordion-wrap aximo-accordion-wrap5" id="aximo-accordion">
                <div class="aximo-accordion-item open">
                    <div class="aximo-accordion-header">
                        <h3>What is a digital marketing agency?</h3>
                        <div class="aximo-accordion-icon active">
                            <i class="icon-minus"></i>
                        </div>
                        <div class="aximo-accordion-icon inactive">
                            <i class="icon-plus"></i>
                        </div>
                    </div>
                    <div class="aximo-accordion-body">
                        <p>A digital marketing agency is a professional organization that specializes in providing online marketing services to businesses and individuals to promote their products..</p>
                    </div>
                </div>
                <div class="aximo-accordion-item">
                    <div class="aximo-accordion-header">
                        <h3>Why do I need a digital marketing agency?</h3>
                        <div class="aximo-accordion-icon active">
                            <i class="icon-minus"></i>
                        </div>
                        <div class="aximo-accordion-icon inactive">
                            <i class="icon-plus"></i>
                        </div>
                    </div>
                    <div class="aximo-accordion-body">
                        <p>Digital marketing agencies have expertise in various online channels and strategies, helping businesses reach their target audience, increase online visibility.</p>
                    </div>
                </div>
                <div class="aximo-accordion-item">
                    <div class="aximo-accordion-header">
                        <h3>What is the cost of digital marketing services?</h3>
                        <div class="aximo-accordion-icon active">
                            <i class="icon-minus"></i>
                        </div>
                        <div class="aximo-accordion-icon inactive">
                            <i class="icon-plus"></i>
                        </div>
                    </div>
                    <div class="aximo-accordion-body">
                        <p>The cost of digital marketing services varies widely depending on the scope of work the our pricing structure. It's essential to discuss your budget and expectations.</p>
                    </div>
                </div>
                <div class="aximo-accordion-item">
                    <div class="aximo-accordion-header">
                        <h3>What is our work process?</h3>
                        <div class="aximo-accordion-icon active">
                            <i class="icon-minus"></i>
                        </div>
                        <div class="aximo-accordion-icon inactive">
                            <i class="icon-plus"></i>
                        </div>
                    </div>
                    <div class="aximo-accordion-body">
                        <p>Our work process will typically involve several key steps to ensure the successful planning, execution, and management of digital marketing campaigns.</p>
                    </div>
                </div>
                <div class="aximo-accordion-item">
                    <div class="aximo-accordion-header">
                        <h3>How to increase social media presence?</h3>
                        <div class="aximo-accordion-icon active">
                            <i class="icon-minus"></i>
                        </div>
                        <div class="aximo-accordion-icon inactive">
                            <i class="icon-plus"></i>
                        </div>
                    </div>
                    <div class="aximo-accordion-body">
                        <p>Increasing your social media presence requires a strategic approach and consistent effort. Some effective strategies to help you boost your social media presence.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End section -->

    <div class="aximo-wave-shape extra-side-margin">
        <img src="assets/images/v5/shape3.png" alt="">
    </div>
    <!-- End shape-->

    <div class="section aximo-section-padding2">
        <div class="container">
            <div class="aximo-section-title libre-font">
                <div class="row">
                    <div class="col-lg-7">
                        <h2>Reviews from our satisfied customers</h2>
                    </div>
                </div>
            </div>
            <div class="swiper aximo-testimonial-slider">
                <div class="swiper-wrapper">
                    <div class="swiper-slide">
                        <div class="aximo-testimonial-slider-column">
                            <div class="aximo-testimonial-slider-wrap">
                                <div class="aximo-testimonial-slider-thumb">
                                    <img src="assets/images/v5/testimonial1.png" alt="">
                                </div>
                                <div class="aximo-testimonial-slider-author">
                                    <h5>William Jack</h5>
                                    <p>Creative Director</p>
                                </div>
                            </div>
                            <div class="aximo-testimonial-slider-data">
                                <h3>They exceeded our expectations</h3>
                                <p>As a startup, you need to find a good marketing partner who can help you connect to the right people. They advertise that they can help our company to increase your sales by up to 78% -- they exceeded our expectations.</p>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-testimonial-slider-column">
                            <div class="aximo-testimonial-slider-wrap">
                                <div class="aximo-testimonial-slider-thumb">
                                    <img src="assets/images/v5/testimonial1.png" alt="">
                                </div>
                                <div class="aximo-testimonial-slider-author">
                                    <h5>William Jack</h5>
                                    <p>Creative Director</p>
                                </div>
                            </div>
                            <div class="aximo-testimonial-slider-data">
                                <h3>They exceeded our expectations</h3>
                                <p>As a startup, you need to find a good marketing partner who can help you connect to the right people. They advertise that they can help our company to increase your sales by up to 78% -- they exceeded our expectations.</p>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-testimonial-slider-column">
                            <div class="aximo-testimonial-slider-wrap">
                                <div class="aximo-testimonial-slider-thumb">
                                    <img src="assets/images/v5/testimonial1.png" alt="">
                                </div>
                                <div class="aximo-testimonial-slider-author">
                                    <h5>William Jack</h5>
                                    <p>Creative Director</p>
                                </div>
                            </div>
                            <div class="aximo-testimonial-slider-data">
                                <h3>They exceeded our expectations</h3>
                                <p>As a startup, you need to find a good marketing partner who can help you connect to the right people. They advertise that they can help our company to increase your sales by up to 78% -- they exceeded our expectations.</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="swiper-pagination"></div>
            </div>

        </div>
    </div>
    <!-- End section -->

    <div class="aximo-cta2-section aximo-section-padding extra-side-margin green-bg">
        <div class="container">
            <div class="aximo-cta2-wrap">
                <h2>
                    Have a project in mind? Let's work together!
                </h2>
                <p>We provides exceptional digital marketing services to help businesses grow our clients online presence. We guarantee top-notch quality.</p>
                <a class="aximo-default-btn corn-btn pill wow fadeInUpX" data-wow-delay="0s" href="contact-us.php">
                    <span class="aximo-label-up">Get In Touch</span>
                    <span class="aximo-label-up">Get In Touch</span>
                </a>
            </div>
        </div>
        <div class="aximo-cta-shape3">
            <img src="assets/images/v5/shape4.png" alt="">
        </div>
    </div>
    <!-- End section -->
</div>
<!-- End all -->

<!-- Footer  -->
<footer class="aximo-footer-section5 bg-light6">
    <div class="container">
        <div class="aximo-footer-top5 aximo-section-padding">
            <div class="row">
                <div class="col-xl-4 col-lg-12">
                    <div class="aximo-footer-textarea">
                        <a href="">
                            <img src="assets/images/logo/logo-dark.svg" alt="">
                        </a>
                        <p>We are a branding agency that digitally works to help companies grow. We have a successful track record of working with various organizations.</p>
                        <div class="aximo-social-icon aximo-social-icon4">
                            <ul>
                                <li>
                                    <a href="https://twitter.com/" target="_blank">
                                        <i class="icon-twitter"></i>
                                    </a>
                                </li>
                                <li>
                                    <a href="https://facebook.com/" target="_blank">
                                        <i class="icon-facebook"></i>
                                    </a>
                                </li>
                                <li>
                                    <a href="https://www.instagram.com/" target="_blank">
                                        <i class="icon-instagram"></i>
                                    </a>
                                </li>
                                <li>
                                    <a href="https://www.linkedin.com/" target="_blank">
                                        <i class="icon-linkedin"></i>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-md-4">
                    <div class="aximo-footer-menu extar-margin">
                        <div class="aximo-footer-title">
                            <p>Special Links</p>
                        </div>
                        <ul>
                            <li><a href="">About us</a></li>
                            <li><a href="">Our services</a></li>
                            <li><a href="">Portfolio</a></li>
                            <li><a href="">Blogs</a></li>
                            <li><a href="">Premium member</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-xl-2 col-md-4">
                    <div class="aximo-footer-menu">
                        <div class="aximo-footer-title">
                            <p>Utility pages</p>
                        </div>
                        <ul>
                            <li><a href="">About us</a></li>
                            <li><a href="">Our services</a></li>
                            <li><a href="">Portfolio</a></li>
                            <li><a href="">Blogs</a></li>
                            <li><a href="">Premium member</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-xl-3 col-md-4">
                    <div class="aximo-footer-menu m-0">
                        <div class="aximo-footer-title">
                            <p>Contact us</p>
                        </div>
                        <div class="aximo-contact-info2 info3">
                            <ul>
                                <li>
                                    <a href="">
                                        <i class="icon-phone"></i>
                                        +088-234-6849
                                    </a>
                                </li>
                                <li>
                                    <a href="">
                                        <i class="icon-message"></i>
                                        example@gmail.com
                                    </a>
                                </li>
                                <li>
                                    <a href="">
                                        <i class="icon-map"></i>
                                        Haward Street,10203 USA
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="aximo-footer-bottom five">
            <div class="aximo-copywright five text-center">
                <p> &copy; Copyright 2024, All Rights Reserved by Pixcels Themes</p>
            </div>
        </div>
    </div>
</footer>

<?php include './partials/layouts/layoutBottom2.php' ?>