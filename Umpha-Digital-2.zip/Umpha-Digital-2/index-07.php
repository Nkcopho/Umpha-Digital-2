<?php include './partials/layouts/layoutTop3.php' ?>

<header class="site-header aximo-header-section aximo-header7" id="sticky-menu">
    <div class="container">
        <nav class="navbar site-navbar">
            <!-- Brand Logo-->
            <div class="brand-logo">
                <a href="index.php">
                    <img src="assets/images/logo/logo-dark.svg" alt="" class="light-version-logo">
                </a>
            </div>
            <div class="menu-block-wrapper">
                <div class="menu-overlay"></div>
                <nav class="menu-block" id="append-menu-header">
                    <div class="mobile-menu-head">
                        <div class="go-back">
                            <i class="fa fa-angle-left"></i>
                        </div>
                        <div class="current-menu-title"></div>
                        <div class="mobile-menu-close">&times;</div>
                    </div>
                    <ul class="site-menu-main">
                        <li class="nav-item nav-item-has-children">
                            <a href="#" class="nav-link-item drop-trigger">Demo <i class="fas fa-angle-down"></i></a>
                            <ul class="sub-menu" id="submenu-1">
                                <li class="sub-menu--item">
                                    <a href="index.php">
                                        <span class="menu-item-text">Design Agency</span>
                                    </a>
                                </li>
                                <li class="sub-menu--item">
                                    <a href="index-02.php">
                                        <span class="menu-item-text">Startup Agency</span>
                                    </a>
                                </li>
                                <li class="sub-menu--item">
                                    <a href="index-03.php">
                                        <span class="menu-item-text">SEO Agency</span>
                                    </a>
                                </li>
                                <li class="sub-menu--item">
                                    <a href="index-04.php">
                                        <span class="menu-item-text">Business Consultation</span>
                                    </a>
                                </li>
                                <li class="sub-menu--item">
                                    <a href="index-05.php">
                                        <span class="menu-item-text">Digital Marketing</span>
                                    </a>
                                </li>
                                <li class="sub-menu--item">
                                    <a href="index-06.php">
                                        <span class="menu-item-text">Interior Design Agency</span>
                                    </a>
                                </li>
                                <li class="sub-menu--item">
                                    <a href="index-07.php">
                                        <span class="menu-item-text">Advertising agency</span>
                                    </a>
                                </li>
                            </ul>
                        </li>
                        <li class="nav-item">
                            <a href="about-us.php" class="nav-link-item">About Us</a>
                        </li>
                        <li class="nav-item nav-item-has-children">
                            <a href="#" class="nav-link-item drop-trigger">Pages <i class="fas fa-angle-down"></i></a>
                            <ul class="sub-menu" id="submenu-2">
                                <li class="sub-menu--item">
                                    <a href="about-us.php">
                                        <span class="menu-item-text">About Us</span>
                                    </a>
                                </li>
                                <li class="sub-menu--item">
                                    <a href="pricing.php">
                                        <span class="menu-item-text">Pricing</span>
                                    </a>
                                </li>
                                <li class="sub-menu--item nav-item-has-children">
                                    <a href="#" data-menu-get="h3" class="drop-trigger">blog <i class="fas fa-angle-down"></i></a>
                                    <ul class="sub-menu shape-none" id="submenu-3">
                                        <li class="sub-menu--item">
                                            <a href="blog.php">
                                                <span class="menu-item-text">Our Blog</span>
                                            </a>
                                        </li>
                                        <li class="sub-menu--item">
                                            <a href="blog-grid.php">
                                                <span class="menu-item-text">Blog grid</span>
                                            </a>
                                        </li>
                                        <li class="sub-menu--item">
                                            <a href="single-blog.php">
                                                <span class="menu-item-text">blog details</span>
                                            </a>
                                        </li>
                                    </ul>
                                </li>
                                <li class="sub-menu--item nav-item-has-children">
                                    <a href="#" data-menu-get="h3" class="drop-trigger">Service<i class="fas fa-angle-down"></i>
                                    </a>
                                    <ul class="sub-menu shape-none" id="submenu-4">
                                        <li class="sub-menu--item">
                                            <a href="service.php">
                                                <span class="menu-item-text">service</span>
                                            </a>
                                        </li>
                                        <li class="sub-menu--item">
                                            <a href="single-service.php">
                                                <span class="menu-item-text">service details</span>
                                            </a>
                                        </li>
                                    </ul>
                                </li>
                                <li class="sub-menu--item nav-item-has-children">
                                    <a href="#" data-menu-get="h3" class="drop-trigger">Team<i class="fas fa-angle-down"></i>
                                    </a>
                                    <ul class="sub-menu shape-none" id="submenu-5">
                                        <li class="sub-menu--item">
                                            <a href="team.php">
                                                <span class="menu-item-text">team</span>
                                            </a>
                                        </li>
                                        <li class="sub-menu--item">
                                            <a href="single-team.php">
                                                <span class="menu-item-text">team details</span>
                                            </a>
                                        </li>
                                    </ul>
                                </li>
                                <li class="sub-menu--item nav-item-has-children">
                                    <a href="#" data-menu-get="h3" class="drop-trigger">Portfolio<i class="fas fa-angle-down"></i>
                                    </a>
                                    <ul class="sub-menu shape-none" id="submenu-6">
                                        <li class="sub-menu--item">
                                            <a href="portfolio-02.php">
                                                <span class="menu-item-text">Portfolio One Column</span>
                                            </a>
                                        </li>
                                        <li class="sub-menu--item">
                                            <a href="portfolio-01.php">
                                                <span class="menu-item-text">Portfolio Two Column</span>
                                            </a>
                                        </li>
                                        <li class="sub-menu--item">
                                            <a href="single-portfolio.php">
                                                <span class="menu-item-text">Single Portfolio</span>
                                            </a>
                                        </li>
                                    </ul>
                                </li>
                                <li class="sub-menu--item nav-item-has-children">
                                    <a href="#" data-menu-get="h3" class="drop-trigger">Utility<i class="fas fa-angle-down"></i>
                                    </a>
                                    <ul class="sub-menu shape-none" id="submenu-7">
                                        <li class="sub-menu--item">
                                            <a href="faq.php">
                                                <span class="menu-item-text">faq</span>
                                            </a>
                                        </li>
                                        <li class="sub-menu--item">
                                            <a href="errors-404.php">
                                                <span class="menu-item-text">Error 404</span>
                                            </a>
                                        </li>
                                        <li class="sub-menu--item">
                                            <a href="testimonial.php">
                                                <span class="menu-item-text">testimonial</span>
                                            </a>
                                        </li>
                                        <li class="sub-menu--item">
                                            <a href="coming-soon.php">
                                                <span class="menu-item-text">Coming Soon</span>
                                            </a>
                                        </li>
                                    </ul>
                                </li>
                                <li class="sub-menu--item nav-item-has-children">
                                    <a href="#" data-menu-get="h3" class="drop-trigger">Account<i class="fas fa-angle-down"></i>
                                    </a>
                                    <ul class="sub-menu shape-none" id="submenu-8">
                                        <li class="sub-menu--item">
                                            <a href="sign-up.php">
                                                <span class="menu-item-text">sign up</span>
                                            </a>
                                        </li>
                                        <li class="sub-menu--item">
                                            <a href="sign-in.php">
                                                <span class="menu-item-text">sign in</span>
                                            </a>
                                        </li>
                                        <li class="sub-menu--item">
                                            <a href="reset-password.php">
                                                <span class="menu-item-text">reset password</span>
                                            </a>
                                        </li>
                                    </ul>
                                </li>
                            </ul>
                        </li>
                        <li class="nav-item nav-item-has-children">
                            <a href="#" class="nav-link-item drop-trigger">Blog <i class="fas fa-angle-down"></i></a>
                            <ul class="sub-menu" id="submenu-9">
                                <li class="sub-menu--item">
                                    <a href="blog.php">
                                        <span class="menu-item-text">blog</span>
                                    </a>
                                </li>
                                <li class="sub-menu--item">
                                    <a href="blog-grid.php">
                                        <span class="menu-item-text">Blog grid</span>
                                    </a>
                                </li>
                                <li class="sub-menu--item">
                                    <a href="single-blog.php">
                                        <span class="menu-item-text">blog Details</span>
                                    </a>
                                </li>
                            </ul>
                        </li>
                        <li class="nav-item">
                            <a href="contact-us.php" class="nav-link-item">Contact Us</a>
                        </li>
                    </ul>
                </nav>
            </div>

            <div class="header-btn header-btn-l1 ms-auto d-none d-xs-inline-flex">
                <a class="aximo-default-btn aximo-header-btn blue-btn2" href="contact-us.php">
                    <span class="aximo-label-up">Hire Us!</span>
                    <span class="aximo-label-up">Hire Us!</span>
                </a>
            </div>
            <!-- mobile menu trigger -->
            <div class="mobile-menu-trigger">
                <span></span>
            </div>
            <!--/.Mobile Menu Hamburger Ends-->
        </nav>
    </div>
</header>
<!--End landex-header-section -->

<div class="bg-light8">

    <div class="aximo-hero-section7">
        <div class="container">
            <div class="row aximo_screenfix_right">
                <div class="col-lg-6 d-flex align-items-center">
                    <div class="aximo-hero-content7">
                        <h1>
                            We present your brand creatively
                            <span class="aximo-hero-shape-title2">
                                <img class="aximo-hero-wave-shape" src="assets/images/v7/title-shape.png" alt="">
                            </span>
                        </h1>
                        <p>Our advertising agency specializes in creating captivating and visually stunning campaigns that leave a lasting impression on audiences to elevate your brand to new heights.</p>
                        <div class="aximo-hero-btn-wrap m-0">
                            <a class="aximo-default-btn blue-btn2 wow fadeInUpX" data-wow-delay="0.1s" href="contact-us.php">
                                <span class="aximo-label-up">Get In Touch</span>
                                <span class="aximo-label-up">Get In Touch</span>
                            </a>
                            <a class="aximo-default-btn aximo-default-btn-outline outline-dark wow fadeInUpX" data-wow-delay="0.2s" href="single-service.php">
                                <span class="aximo-label-up">Explore Our Services</span>
                                <span class="aximo-label-up">Explore Our Services</span>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="aximo-hero-thumb7">
                        <img src="assets/images/v7/hero-thumb.png" alt="">
                    </div>
                </div>
            </div>
        </div>
        <div class="aximo-hero-shapev7">
            <img src="assets/images/v7/hero-shape.png" alt="">
        </div>
    </div>
    <!-- end section -->

    <div class="aximo-brandlogo-section3">
        <div class="container">
            <div class="aximo-brandlogo-title3">
                <p>We are happy to work and share creative vision with international partners such as:</p>
            </div>
            <div class="swiper aximo-auto-slider">
                <div class="swiper-wrapper">
                    <div class="swiper-slide">
                        <div class="aximo-brandlogo-item2">
                            <img src="assets/images/v7/brand1.png" alt="">
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-brandlogo-item2">
                            <img src="assets/images/v7/brand2.png" alt="">
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-brandlogo-item2">
                            <img src="assets/images/v7/brand3.png" alt="">
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-brandlogo-item2">
                            <img src="assets/images/v7/brand4.png" alt="">
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-brandlogo-item2">
                            <img src="assets/images/v7/brand5.png" alt="">
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-brandlogo-item2">
                            <img src="assets/images/v7/brand6.png" alt="">
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-brandlogo-item2">
                            <img src="assets/images/v7/brand7.png" alt="">
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-brandlogo-item2">
                            <img src="assets/images/v7/brand8.png" alt="">
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-brandlogo-item2">
                            <img src="assets/images/v7/brand1.png" alt="">
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-brandlogo-item2">
                            <img src="assets/images/v7/brand2.png" alt="">
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-brandlogo-item2">
                            <img src="assets/images/v7/brand3.png" alt="">
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-brandlogo-item2">
                            <img src="assets/images/v7/brand4.png" alt="">
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-brandlogo-item2">
                            <img src="assets/images/v7/brand5.png" alt="">
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-brandlogo-item2">
                            <img src="assets/images/v7/brand6.png" alt="">
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-brandlogo-item2">
                            <img src="assets/images/v7/brand7.png" alt="">
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-brandlogo-item2">
                            <img src="assets/images/v7/brand8.png" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- end section -->

    <div class="section aximo-section-padding2">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <div class="aximo-content-thumb wow fadeInLeft" data-wow-delay="0.1s">
                        <img src="assets/images/v7/thumb1.png" alt="">
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="aximo-default-content bricolage-font">
                        <h2>To analyze the market demand for a product</h2>
                        <p>We conduct thorough market research to comprehend our target audience, industry trends, and competitors. This data serves as the foundation for creating effective advertising strategies.</p>
                        <div class="aximo-list-icon2">
                            <ul>
                                <li><img src="assets/images/v7/check.png" alt=""><span>Market Research: </span>Conducting market research to gather main information about the target audience, competitors trends.</li>
                                <li><img src="assets/images/v7/check.png" alt=""><span>Strategic Planning:</span> We work closely with clients to define clear advertising objectives and develop a comprehensive strategy.</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End section -->

    <div class="section aximo-section-padding6">
        <div class="container">
            <div class="row">
                <div class="col-lg-5 order-lg-2">
                    <div class="aximo-content-thumb wow fadeInRight" data-wow-delay="0.1s">
                        <img src="assets/images/v7/thumb2.png" alt="">
                    </div>
                </div>
                <div class="col-lg-7">
                    <div class="aximo-default-content bricolage-font">
                        <h2>Identifying the most appropriate media channels</h2>
                        <p>We identify the most appropriate media channels to reach the target audience. We negotiate & purchase advertising space or time, optimizing placement for maximum impact and cost-effectiveness.</p>
                        <div class="aximo-list-icon2">
                            <ul>
                                <li><img src="assets/images/v7/check.png" alt=""><span>Creative Development: </span> We are responsible for creating attractive and eye-catching advertisements across various platforms.</li>
                                <li><img src="assets/images/v7/check.png" alt=""><span>Media Planning and Buying:</span> We negotiate and purchase advertising space or time, optimizing placement for maximum impact.</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End section -->

    <div class="section aximo-section-padding6">
        <div class="container">
            <div class="aximo-section-title center bricolage-font">
                <h2>Nurturing a robust brand identity</h2>
            </div>
            <div class="aximo-video-wrap2 wow fadeInUpX" data-wow-delay="0s">
                <img src="assets/images/v7/video-bg.png" alt="">
                <a class="aximo-video-popupv7 video-init" href="https://www.youtube.com/watch?v=7e90gBu4pas">
                    <img src="assets/images/v7/play-btn.png" alt="">
                    <div class="waves waves7 wave-1"></div>
                    <div class="waves waves7 wave-2"></div>
                    <div class="waves waves7 wave-3"></div>
                </a>
                <div class="aximo-video-shapev7">
                    <img src="assets/images/v7/shape.png" alt="">
                </div>
            </div>
        </div>
    </div>
    <!-- End section -->

    <div class="section dark-bg3 aximo-section-padding5">
        <div class="container">
            <div class="aximo-section-title light bricolage-font">
                <div class="row">
                    <div class="col-lg-7">
                        <h2>What we can do for your brand</h2>
                    </div>
                    <div class="col-lg-5 d-flex align-items-center justify-content-end">
                        <div class="aximo-title-btn">
                            <a class="aximo-default-btn blue-btn2 wow fadeInUpX" data-wow-delay="0.1s" href="service.php">
                                <span class="aximo-label-up">View All Services</span>
                                <span class="aximo-label-up">View All Services</span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="aximo-service7-wrap">
                <div class="aximo-service7-title">
                    <h3>1. Ad Campaigns:</h3>
                </div>
                <div class="aximo-service7-description">
                    <p>Crafting and executing comprehensive advertising campaigns to reach the target audience effectively.</p>
                </div>
                <a class="aximo-service7-btn" href="single-service.php">
                    <svg width="50" height="49" viewBox="0 0 50 49" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M38.0375 27.4312L0 27.4312V21.1812L38.0375 21.1812L21.275 4.41875L25.6938 0L50 24.3062L25.6938 48.6125L21.275 44.1937L38.0375 27.4312Z" fill="#F8FCDD" />
                    </svg>
                </a>
            </div>
            <div class="aximo-service7-wrap">
                <div class="aximo-service7-title">
                    <h3>2. Strategic Planning</h3>
                </div>
                <div class="aximo-service7-description">
                    <p>Guide advertising efforts, ensuring alignment with overall business goals and market conditions.</p>
                </div>
                <a class="aximo-service7-btn" href="single-service.php">
                    <svg width="50" height="49" viewBox="0 0 50 49" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M38.0375 27.4312L0 27.4312V21.1812L38.0375 21.1812L21.275 4.41875L25.6938 0L50 24.3062L25.6938 48.6125L21.275 44.1937L38.0375 27.4312Z" fill="#F8FCDD" />
                    </svg>
                </a>
            </div>
            <div class="aximo-service7-wrap">
                <div class="aximo-service7-title">
                    <h3>3. TV Advertising:</h3>
                </div>
                <div class="aximo-service7-description">
                    <p>Effective TV advertising is the auditory aspect of the medium to convey the client's message.</p>
                </div>
                <a class="aximo-service7-btn" href="single-service.php">
                    <svg width="50" height="49" viewBox="0 0 50 49" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M38.0375 27.4312L0 27.4312V21.1812L38.0375 21.1812L21.275 4.41875L25.6938 0L50 24.3062L25.6938 48.6125L21.275 44.1937L38.0375 27.4312Z" fill="#F8FCDD" />
                    </svg>
                </a>
            </div>
            <div class="aximo-service7-wrap">
                <div class="aximo-service7-title">
                    <h3>4. Social Media Ads:</h3>
                </div>
                <div class="aximo-service7-description">
                    <p>Designing and implementing advertising strategies on various social media to increase brand visibility.</p>
                </div>
                <a class="aximo-service7-btn" href="single-service.php">
                    <svg width="50" height="49" viewBox="0 0 50 49" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M38.0375 27.4312L0 27.4312V21.1812L38.0375 21.1812L21.275 4.41875L25.6938 0L50 24.3062L25.6938 48.6125L21.275 44.1937L38.0375 27.4312Z" fill="#F8FCDD" />
                    </svg>
                </a>
            </div>
            <div class="aximo-service7-wrap">
                <div class="aximo-service7-title">
                    <h3>5. Direct Mail Ads:</h3>
                </div>
                <div class="aximo-service7-description">
                    <p>Creating targeted and personalized advertising materials sent directly to a predefined audience.</p>
                </div>
                <a class="aximo-service7-btn" href="single-service.php">
                    <svg width="50" height="49" viewBox="0 0 50 49" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M38.0375 27.4312L0 27.4312V21.1812L38.0375 21.1812L21.275 4.41875L25.6938 0L50 24.3062L25.6938 48.6125L21.275 44.1937L38.0375 27.4312Z" fill="#F8FCDD" />
                    </svg>
                </a>
            </div>
        </div>
    </div>
    <!-- End section -->

    <div class="section aximo-section-padding4">
        <div class="container">
            <div class="aximo-section-title center bricolage-font">
                <h2>Take a look at our most recent work</h2>
            </div>
        </div>
        <div class="img-container-wrap">
            <div class="aximo-image-resizing-item wow fadeInUpX" data-wow-delay="0.1s" style="background-image: url(assets/images/v7/slider-thumb1.png);">
                <div class="aximo-image-resizing-content">
                    <a href="single-portfolio.php">
                        <h4>#ZenithZest Campaign</h4>
                    </a>
                    <p>Comprehensive advertising strategy, contributing to a well-rounded and effective marketing campaign.</p>
                </div>
            </div>

            <div class="aximo-image-resizing-item wow fadeInUpX" data-wow-delay="0.2s" style="background-image: url(assets/images/v7/slider-thumb2.png);">
                <div class="aximo-image-resizing-content">
                    <a href="single-portfolio.php">
                        <h4>#VerveVista Venture</h4>
                    </a>
                    <p>Comprehensive advertising strategy, contributing to a well-rounded and effective marketing campaign.</p>
                </div>
            </div>

            <div class="aximo-image-resizing-item wow fadeInUpX" data-wow-delay="0.3s" style="background-image: url(assets/images/v7/slider-thumb3.png);">
                <div class="aximo-image-resizing-content">
                    <a href="single-portfolio.php">
                        <h4>#Project Luminosity</h4>
                    </a>
                    <p>Comprehensive advertising strategy, contributing to a well-rounded and effective marketing campaign.</p>
                </div>
            </div>

            <div class="aximo-image-resizing-item wow fadeInUpX" data-wow-delay="0.4s" style="background-image: url(assets/images/v7/slider-thumb4.png);">
                <div class="aximo-image-resizing-content">
                    <a href="single-portfolio.php">
                        <h4>#InnoVibes Campaign</h4>
                    </a>
                    <p>Comprehensive advertising strategy, contributing to a well-rounded and effective marketing campaign.</p>
                </div>
            </div>

            <div class="aximo-image-resizing-item wow fadeInUpX" data-wow-delay="0.5s" style="background-image: url(assets/images/v7/slider-thumb5.png);">
                <div class="aximo-image-resizing-content">
                    <a href="single-portfolio.php">
                        <h4>#EpicEcho Initiative</h4>
                    </a>
                    <p>Comprehensive advertising strategy, contributing to a well-rounded and effective marketing campaign.</p>
                </div>
            </div>

            <div class="aximo-image-resizing-item wow fadeInUpX" data-wow-delay="0.6s" style="background-image: url(assets/images/v7/slider-thumb6.png);">
                <div class="aximo-image-resizing-content">
                    <a href="single-portfolio.php">
                        <h4>#MomentumXperience</h4>
                    </a>
                    <p>Comprehensive advertising strategy, contributing to a well-rounded and effective marketing campaign.</p>
                </div>
            </div>

            <div class="aximo-image-resizing-item wow fadeInUpX" data-wow-delay="0.7s" style="background-image: url(assets/images/v7/slider-thumb7.png);">
                <div class="aximo-image-resizing-content">
                    <a href="single-portfolio.php">
                        <h4>#PulseFusion Project</h4>
                    </a>
                    <p>Comprehensive advertising strategy, contributing to a well-rounded and effective marketing campaign.</p>
                </div>
            </div>

            <div class="aximo-image-resizing-item wow fadeInUpX" data-wow-delay="0.8s" style="background-image: url(assets/images/v7/slider-thumb8.png);">
                <div class="aximo-image-resizing-content">
                    <a href="single-portfolio.php">
                        <h4>#NexGen Nexus</h4>
                    </a>
                    <p>Comprehensive advertising strategy, contributing to a well-rounded and effective marketing campaign.</p>
                </div>
            </div>

        </div>

    </div>
    <!-- End section -->

    <div class="section aximo-section-padding3 position-relative">
        <div class="container">
            <div class="aximo-section-title bricolage-font position-relative z-index">
                <div class="row">
                    <div class="col-lg-6">
                        <h2>Talented people of our company</h2>
                    </div>
                    <div class="col-lg-6 d-flex align-items-center justify-content-end">
                        <div class="aximo-title-btn">
                            <a class="aximo-default-btn blue-btn2 wow fadeInUpX" data-wow-delay="0.1s" href="team.php">
                                <span class="aximo-label-up">Meet All Members</span>
                                <span class="aximo-label-up">Meet All Members</span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-xl-4 col-md-6">
                    <div class="aximo-team-wrap3 wow fadeInUpX" data-wow-delay="0.1s">
                        <div class="aximo-team-thumb3">
                            <img src="assets/images/team/team13.png" alt="">
                        </div>
                        <div class="aximo-team-data3">
                            <a href="single-team.php">
                                <h3>Adam Smith</h3>
                            </a>
                            <p>Head of Digital Advertising</p>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-md-6">
                    <div class="aximo-team-wrap3 wow fadeInUpX" data-wow-delay="0.2s">
                        <div class="aximo-team-thumb3">
                            <img src="assets/images/team/team14.png" alt="">
                        </div>
                        <div class="aximo-team-data3">
                            <a href="single-team.php">
                                <h3>Justine Mark</h3>
                            </a>
                            <p>Commercial Director</p>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-md-6">
                    <div class="aximo-team-wrap3 wow fadeInUpX" data-wow-delay="0.3s">
                        <div class="aximo-team-thumb3">
                            <img src="assets/images/team/team15.png" alt="">
                        </div>
                        <div class="aximo-team-data3">
                            <a href="single-team.php">
                                <h3>Robert Harz</h3>
                            </a>
                            <p>Chief Data Officer</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="aximo-team-shapev7">
            <img src="assets/images/v7/hero-shape.png" alt="">
        </div>
    </div>
    <!-- End section -->

    <div class="aximo-testimonial-slider-section aximo-section-padding">
        <div class="container">
            <div class="aximo-section-title bricolage-font center light">
                <h2>We’re trusted advertising agency</h2>
            </div>
            <div class="swiper aximo-testimonial-slider2">
                <div class="swiper-wrapper">
                    <div class="swiper-slide">
                        <div class="aximo-testimonial-slider-wrap2">
                            <div class="aximo-testimonial-slider-rating">
                                <ul>
                                    <li><img src="assets/images/v7/star1.png" alt=""></li>
                                    <li><img src="assets/images/v7/star2.png" alt=""></li>
                                    <li><img src="assets/images/v7/star1.png" alt=""></li>
                                </ul>
                            </div>
                            <div class="aximo-testimonial-slider-description">
                                <p>"The team at Masco has an incredible knack for turning ideas into visually stunning and compelling campaigns. Their creative approach brought a fresh and innovative perspective to our brand, resulting in increased engagement and brand recognition."</p>
                            </div>
                            <div class="aximo-testimonial-slider-author-data">
                                <span>William Jack </span>
                                <p>CEO & Founder @XYZ</p>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-testimonial-slider-wrap2">
                            <div class="aximo-testimonial-slider-rating">
                                <ul>
                                    <li><img src="assets/images/v7/star1.png" alt=""></li>
                                    <li><img src="assets/images/v7/star2.png" alt=""></li>
                                    <li><img src="assets/images/v7/star1.png" alt=""></li>
                                </ul>
                            </div>
                            <div class="aximo-testimonial-slider-description">
                                <p>"The team at Masco has an incredible knack for turning ideas into visually stunning and compelling campaigns. Their creative approach brought a fresh and innovative perspective to our brand, resulting in increased engagement and brand recognition."</p>
                            </div>
                            <div class="aximo-testimonial-slider-author-data">
                                <span>William Jack </span>
                                <p>CEO & Founder @XYZ</p>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>

</div>
<!-- End all -->

<!-- Footer  -->
<footer class="aximo-footer-section7 bg-light8 aximo-section-padding4">
    <div class="container">
        <div class="aximo-section-title bricolage-font p-0">
            <div class="row">
                <div class="col-lg-7">
                    <h2>
                        Let your brand rise to new heights
                        <span class="aximo-title-shape">
                            <img src="assets/images/v7/title-shape.png" alt="">
                        </span>
                    </h2>
                </div>
                <div class="col-lg-5 d-flex align-items-center">
                    <div class="aximo-title-btn">
                        <a class="aximo-default-btn blue-btn2" href="contact-us.php">
                            <span class="aximo-label-up">Explore Our Plans</span>
                            <span class="aximo-label-up">Explore Our Plans</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>


        <div class="aximo-footer-top7">
            <div class="aximo-footer-info-column">
                <div class="aximo-footer-info-item">
                    <a href="">
                        <img src="assets/images/logo/logo-dark.svg" alt="">
                    </a>
                </div>
                <div class="aximo-footer-info-item">
                    <h5>Our address:</h5>
                    <p>4517 Washington Ave.<br> Manchester, Kentucky 39495</p>
                </div>
                <div class="aximo-footer-info-item">
                    <h5>Give us a call:</h5>
                    <a href="">(123) 456-7890</a>
                    <a href="">(088) 123-4567</a>
                </div>
                <div class="aximo-footer-info-item">
                    <h5>Send us an email:</h5>
                    <a href="mailto:pixcelsthemes@gmail.com">pixcelsthemes@gmail.com</a>
                </div>
            </div>
        </div>
        <div class="aximo-footer-bottom seven">
            <div class="row">
                <div class="col-lg-6 order-lg-2">
                    <div class="aximo-social-icon6 right">
                        <ul>
                            <li>
                                <a href="https://twitter.com/" target="_blank">
                                    <i class="icon-twitter"></i>
                                </a>
                            </li>
                            <li>
                                <a href="https://facebook.com/" target="_blank">
                                    <i class="icon-facebook"></i>
                                </a>
                            </li>
                            <li>
                                <a href="https://www.instagram.com/" target="_blank">
                                    <i class="icon-instagram"></i>
                                </a>
                            </li>
                            <li>
                                <a href="https://www.linkedin.com/" target="_blank">
                                    <i class="icon-linkedin"></i>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-6 d-flex align-items-center">
                    <div class="aximo-copywright seven">
                        <p> &copy; Copyright 2024, All Rights Reserved by Pixcels Themes</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>

<?php include './partials/layouts/layoutBottom2.php' ?>