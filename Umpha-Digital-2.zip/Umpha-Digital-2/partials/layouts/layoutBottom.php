<?php include './partials/footer.php' ?>

<?php include './partials/script.php' ?>

</body>

</html>