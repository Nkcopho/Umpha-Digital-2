<!DOCTYPE html>
<html lang="en">

<?php include './partials/head.php' ?>

<body class="light">

    <?php include './partials/preloader.php' ?>

    <?php include './partials/header.php' ?>
    <!--End landex-header-section -->
