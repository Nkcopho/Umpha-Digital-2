<!-- scripts -->
  <script src="/assets/js/jquery-3.6.0.min.js"></script>
  <script src="/assets/js/bootstrap.bundle.min.js"></script>
  <script src="/assets/js/aos.js"></script>
  <script src="/assets/js/menu/menu.js"></script>
  <script src="/assets/js/gsap.min.js"></script>
  <script src="/assets/js/isotope.pkgd.min.js"></script>
  <script src="/assets/js/jquery.magnific-popup.min.js"></script>
  <script src="/assets/js/swiper-bundle.min.js"></script>
  <script src="/assets/js/countdown.js"></script>
  <script src="/assets/js/wow.min.js"></script>
  <script src="/assets/js/SplitText.min.js"></script>
  <script src="/assets/js/ScrollTrigger.min.js"></script>
  <script src="/assets/js/ScrollSmoother.min.js"></script>
  <script src="/assets/js/skill-bar.js"></script>
  <script src="/assets/js/infinite-slider.js"></script>
  <script src="/assets/js/image-resizing.js"></script>
  <!-- <script src="assets/js/scrollsmooth.js"></script> -->
  <script src="/assets/js/faq.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?v=3&key=AIzaSyArZVfNvjnLNwJZlLJKuOiWHZ6vtQzzb1Y"></script>

  <script src="/assets/js/app.js"></script>