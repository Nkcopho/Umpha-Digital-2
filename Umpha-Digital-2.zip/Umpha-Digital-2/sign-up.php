<?php include './partials/layouts/layoutTop3.php' ?>

  <div class="aximo-logo-section">
    <div class="container">
      <a href="index.php">
        <img src="assets/images/logo/logo-white.svg" alt="">
      </a>
    </div>
  </div>
  <!-- end -->

  <div class="section aximo-section-padding">
    <div class="container">
      <div class="aximo-account-title">
        <h2>
          <span class="aximo-title-animation">
          Create Account
          <span class="aximo-title-icon">
            <img src="assets/images/v1/star2.png" alt="">
          </span>
          </span>
        </h2>
      </div>
      <div class="aximo-account-wrap wow fadeInUpX" data-wow-delay="0.1s">
        <form action="#">
          <div class="aximo-account-field">
            <label>Enter your full name</label>
            <input type="text" placeholder="Adam Smith">
          </div>
          <div class="aximo-account-field">
            <label>Enter email address</label>
            <input type="email" placeholder="example@gmail.com">
          </div>
          <div class="aximo-account-field">
            <label>Enter Password</label>
            <input type="password" placeholder="Enter Password">
          </div>
          <div class="aximo-account-checkbox">
            <input type="checkbox" id="check">
            <label for="check">I have read and accept the <a href="">Terms & Conditions</a> and <a href=""> Privacy Policy</a> </label>
          </div>
          <button id="aximo-account-btn" type="submit">Create account</button>
          <div class="aximo-or">
            <p>or</p>
          </div>
          <a href="#" class="aximo-connect-login">
            <img src="assets/images/icon/google.svg" alt="">
            Sign up with Google
          </a>
          <a href="#" class="aximo-connect-login">
            <img src="assets/images/icon/facebook.svg" alt="">
            Sign up with Facebook
          </a>

          <div class="aximo-account-bottom">
            <p>Already have an account? <a href="sign-in.php">Log in here</a></p>
          </div>
        </form>
      </div>
    </div>
  </div>

  <?php include './partials/layouts/layoutBottom2.php' ?>